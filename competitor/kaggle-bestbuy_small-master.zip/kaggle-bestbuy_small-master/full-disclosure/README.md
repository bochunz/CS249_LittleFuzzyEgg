kaggle-bestbuy_small
====================

See [http://fastml.com/best-buy-mobile-contest-full-disclosure/](http://fastml.com/best-buy-mobile-contest-full-disclosure/) for description.

	correct.py - a module with spelling utilities
	names.php - a script to extract SKUs and names from XML
	prepare.py - a module with one utility function, prepare()
	sku_name.tsv - SKU to name mapping
	sku_name_prepared.tsv - SKU to name mapping, names processed by prepare()
	train6.py - final and highest scoring version of the main script