kaggle-bestbuy_small
====================

See [http://fastml.com/best-buy-mobile-contest/](http://fastml.com/best-buy-mobile-contest/) for description.